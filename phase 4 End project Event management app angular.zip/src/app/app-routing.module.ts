import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeCreateComponent } from './employee-create/employee-create.component';
import { EmployeeUpdateComponent } from './employee-update/employee-update.component';
import { EmployeeDeleteComponent } from './employee-delete/employee-delete.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { AuthGuard } from './auth.guard';
import { NavbarComponent } from './navbar/navbar.component';
import { ChangePasswordComponent } from './change-password/change-password.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: AdminLoginComponent },
  { path: 'change-password', component: ChangePasswordComponent },
  {
    path: 'employees',
    
    children: [
      { path: '', component: EmployeeListComponent ,canActivateChild: [AuthGuard]},
      { path: 'create', component: EmployeeCreateComponent,canActivateChild: [AuthGuard] },
      { path: 'update/:id', component: EmployeeUpdateComponent,canActivateChild: [AuthGuard] },
      { path: 'delete/:id', component: EmployeeDeleteComponent,canActivateChild: [AuthGuard] },
      { path: 'details/:id', component: EmployeeDetailsComponent,canActivateChild: [AuthGuard] }
    ]
  },
  { path: '**', redirectTo: 'login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
