import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private password: string ='admin';

  setPassword(password: string) {
    this.password = password;
  }

  getPassword() {
    return this.password;
  }
}
