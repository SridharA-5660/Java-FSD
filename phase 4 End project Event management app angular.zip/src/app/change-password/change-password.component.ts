import { Component } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent {
  currentPassword: string = '';
  newPassword: string = '';
  confirmPassword: string = '';

  constructor(private authService: AuthService) {}

  changePassword() {
    const currentPassword = this.authService.getPassword();
    if (this.currentPassword === currentPassword && this.newPassword === this.confirmPassword) {
      this.authService.setPassword(this.newPassword);
      alert('Password changed successfully!');
      this.currentPassword = '';
      this.newPassword = '';
      this.confirmPassword = '';
    } else {
      alert('Invalid password or the new password and confirm password do not match.');
    }
  }
}
