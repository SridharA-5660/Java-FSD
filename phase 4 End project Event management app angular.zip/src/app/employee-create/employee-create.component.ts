import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-create',
  templateUrl: './employee-create.component.html',
  styleUrls: ['./employee-create.component.css']
})
export class EmployeeCreateComponent {
  employee = {
    first_name: '',
    last_name: '',
    email: ''
  };

  constructor(private router: Router, private employeeService: EmployeeService) {}

  createEmployee() {
    this.employeeService.createEmployee(this.employee).subscribe(
      () => {
        this.router.navigate(['/employees']);
      },
      (error: any) => {
        console.error('Error:', error);
      }
    );
  }
  goToEmployeeList(){
    this.router.navigate(['/employees']);
  }
}
