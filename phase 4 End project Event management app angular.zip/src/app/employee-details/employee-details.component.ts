import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
  employee: any;

  constructor(private route: ActivatedRoute, private router: Router, private employeeService: EmployeeService) {}

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.employeeService.getEmployee(id).subscribe(
      (response: any) => {
        this.employee = response;
      },
      (error: any) => {
        console.error('Error:', error);
      }
    );
  }

  goToEmployeeList() {
    this.router.navigate(['/employees']);
  }

  goToUpdateEmployee() {
    this.router.navigate(['/employees/update', this.employee.id]);
  }

  deleteEmployee() {
    if (confirm('Are you sure you want to delete this employee?')) {
      this.employeeService.deleteEmployee(this.employee.id).subscribe(
        () => {
          this.router.navigate(['/employees']);
        },
        (error: any) => {
          console.error('Error:', error);
        }
      );
    }
  }
}
