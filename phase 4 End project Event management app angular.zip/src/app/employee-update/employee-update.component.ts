import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-update',
  templateUrl: './employee-update.component.html',
  styleUrls: ['./employee-update.component.css']
})
export class EmployeeUpdateComponent implements OnInit {
  employee: any;

  constructor(private route: ActivatedRoute, private router: Router, private employeeService: EmployeeService) {}

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.employeeService.getEmployee(id).subscribe(
      (response: any) => {
        this.employee = response;
      },
      (error: any) => {
        console.error('Error:', error);
      }
    );
  }

  updateEmployee() {
    this.employeeService.updateEmployee(this.employee.id, this.employee).subscribe(
      () => {
        this.router.navigate(['/employees']);
      },
      (error: any) => {
        console.error('Error:', error);
      }
    );
  }

  
  viewEmployee(id: number) {
    this.router.navigate(['/employees/details',id]);
  }
}
